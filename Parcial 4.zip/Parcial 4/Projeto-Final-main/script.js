const images = document.querySelectorAll('.slideshow img');
let currentImageIndex = 0;

function showImage(index) {
    images[currentImageIndex].style.display = 'none';
    currentImageIndex = index;
    images[currentImageIndex].style.display = 'block';
}

function nextImage() {
    const nextIndex = (currentImageIndex + 1) % images.length;
    showImage(nextIndex);
}


showImage(currentImageIndex);
setInterval(nextImage, 2000);
