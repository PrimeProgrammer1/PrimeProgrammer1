


   function sugestoes(){
    var lista = document.getElementById("lista");
    var sugest = document.getElementById("sugestao").value;
    
    if (sugest.length == 0){
        alert("Digite o nome do prato!");
        return;
    }

    var criaLi = document.createElement("li");

    const criaTexto = document.createTextNode(sugest);
    criaLi.appendChild(criaTexto);
    lista.appendChild(criaLi);
   }



const images = document.querySelectorAll('.slideshow img');
let currentImageIndex = 0;

function showImage(index) {
   images[currentImageIndex].style.display = 'none';
   currentImageIndex = index;
   images[currentImageIndex].style.display = 'block';
}

function nextImage() {
   const nextIndex = (currentImageIndex + 1) % images.length;
   showImage(nextIndex);
}

showImage(currentImageIndex);
setInterval(nextImage, 5000);
