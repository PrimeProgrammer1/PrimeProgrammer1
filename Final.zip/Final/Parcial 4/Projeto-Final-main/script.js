const images = document.querySelectorAll('.slideshow img');
let currentImageIndex = 0;

function showImage(index) {
    images[currentImageIndex].style.display = 'none';
    currentImageIndex = index;
    images[currentImageIndex].style.display = 'block';
}

function nextImage() {
    const nextIndex = (currentImageIndex + 1) % images.length;
    showImage(nextIndex);
}

// Iniciar o slideshow
showImage(currentImageIndex);
setInterval(nextImage, 2000); // Troca de imagem a cada 2 segundos
